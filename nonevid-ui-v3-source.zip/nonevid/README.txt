nonevid - Android prototype (UI v2, matches the supplied design mock-ups)

Tabs: Home, Explore, Wallet, Profile (Settings lives inside Profile).
- Home: Joker hero banner (cropped, never stretched), Categories, Trending This Week, Watch & Earn banner.
- Explore: TikTok-style vertical feed (Following / For You, like, comments, share, follow). Real looping videos (Media3, sample clips, tap to pause); explore_bg is the poster shown until the first frame.
- Wallet: token card, daily bonus (local), stats and recent transactions.
- Profile: avatar, level card (crown + Lv.12 badge), menu, Log Out.
- Settings (Profile > Settings): Appearance, Notifications, Security & Privacy, Identity Verification, Saved Movies, Add Account.

Important
- Everything is a local prototype. Login, tokens, rewards, identity check, 2-step toggle and notifications are NOT connected to any server.
- Demo seed values (balance 48,750, 12.5h, rank #245, +12.5%, Premium/Silver labels, Profile stats, feed counters) come from the mock-up and are placeholders.
- Real behaviour: every 15 minutes of actual playback adds 1,000 tokens (lower REWARD_SEC in Store.kt to test), the daily bonus adds 500 once per day, history/saved/PIN/appearance are stored on the device.
- All movie cards open the same public sample video.
- Images are in app/src/main/res/drawable-nodpi (cut from the supplied sheets). poster_alt_1 = Matrix poster, poster_alt_5 = vertical Joker poster; unused assets were removed.
- explore_bg.jpg was upscaled from a small source (184x381); replace it with a high-resolution image for a sharp Explore screen.
- Movie/poster artwork is copyrighted promotional material: keep this build private.

Build
- Android Studio (Koala or newer, JDK 17): open this folder, wait for Gradle sync, Run. APK: Build > Build APK(s).
- Without a PC: push this folder to a GitHub repo; .github/workflows/build.yml builds app-debug.apk
  (Actions tab > latest run > Artifacts > nonevid-debug-apk).
- Toolchain: Gradle 8.7+, AGP 8.5.2, Kotlin 1.9.24, Compose compiler 1.5.14, compileSdk 34, minSdk 24.
