package com.example.moviehub

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Bookmarks
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Help
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ProfileScreen(st: Store, nav: Nav) {
    var editing by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar(nav)
        Row(Modifier.padding(horizontal = 24.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(112.dp)) {
                Image(painterResource(R.drawable.avatar), null, Modifier.size(104.dp).align(Alignment.TopStart), contentScale = ContentScale.Fit)
                Box(
                    Modifier.align(Alignment.BottomEnd).size(34.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary).clickable { editing = true },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Edit, "Edit name", tint = Color.White, modifier = Modifier.size(18.dp)) }
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text(st.name, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.crown), null, Modifier.size(20.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Premium Member", fontSize = 14.sp, color = PurpleLight) // demo label
                }
                Text(st.phone, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(14.dp))
        // Profile stats are demo values taken from the design mock-up.
        Row(Modifier.padding(horizontal = 16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            ProfileStat({ Image(painterResource(R.drawable.play_circle), null, Modifier.size(26.dp)) }, "24.8h", "Watching")
            ProfileStat({ Icon(Icons.Filled.Star, null, tint = Gold, modifier = Modifier.size(26.dp)) }, "4.8", "Rating")
            ProfileStat({ Image(painterResource(R.drawable.gift_orange), null, Modifier.size(26.dp)) }, "12", "Rewards")
        }
        Spacer(Modifier.height(14.dp))
        Row(
            Modifier.padding(horizontal = 16.dp).then(glass()).fillMaxWidth().clickable { nav.open(Ov.Page("level")) }.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Image(painterResource(R.drawable.crown), null, Modifier.size(52.dp))
            Image(painterResource(R.drawable.level_badge), "Level 12", Modifier.size(width = 62.dp, height = 52.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Your Level", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Silver Member", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LinearProgressIndicator(progress = { 0.6f }, Modifier.weight(1f).height(6.dp).clip(CircleShape), color = MaterialTheme.colorScheme.primary, trackColor = MaterialTheme.colorScheme.outline)
                    Spacer(Modifier.width(8.dp))
                    Text("Level 2 • 60%", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onBackground)
        }
        Spacer(Modifier.height(14.dp))
        Column(Modifier.padding(horizontal = 16.dp).then(glass()).fillMaxWidth()) {
            MenuRow(Icons.Outlined.AccountBalanceWallet, "My Wallet") { nav.tab(2) }
            MenuDivider()
            MenuRow(Icons.Outlined.History, "Watch History") { nav.open(Ov.History) }
            MenuDivider()
            MenuRow(Icons.Outlined.Notifications, "Notifications", badge = "3") { nav.open(Ov.Page("notifications")) }
            MenuDivider()
            MenuRow(Icons.Outlined.Settings, "Settings") { nav.open(Ov.Page("settings")) }
            MenuDivider()
            MenuRow(Icons.Outlined.Help, "Help & Support") { info = "help" }
            MenuDivider()
            MenuRow(Icons.Outlined.Info, "About Nonevid") { info = "about" }
        }
        Spacer(Modifier.height(16.dp))
        Row(
            Modifier.padding(horizontal = 16.dp).fillMaxWidth().clip(RoundedCornerShape(50))
                .background(Brush.horizontalGradient(listOf(Color(0xFF5B1FB8), Color(0xFF7B2FE0))))
                .clickable { st.loggedIn = false }.padding(vertical = 15.dp),
            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.AutoMirrored.Filled.Logout, null, tint = Color.White, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text("Log Out", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        }
        Spacer(Modifier.height(120.dp))
    }

    if (editing) {
        var n by remember { mutableStateOf(st.name) }
        AlertDialog(
            onDismissRequest = { editing = false }, title = { Text("Edit name") },
            text = { OutlinedTextField(n, { n = it }, singleLine = true) },
            confirmButton = {
                TextButton({
                    val clean = n.replace(Regex("[;|]"), " ").trim()
                    if (clean.isNotEmpty()) {
                        st.accounts = st.accounts.replace("${st.name}|${st.phone}", "$clean|${st.phone}")
                        st.name = clean
                    }
                    editing = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton({ editing = false }) { Text("Cancel") } },
        )
    }
    if (info.isNotEmpty()) InfoDialog(info) { info = "" }
}

@Composable
fun InfoDialog(kind: String, onClose: () -> Unit) = AlertDialog(
    onDismissRequest = onClose,
    confirmButton = { TextButton(onClose) { Text("Close") } },
    title = { Text(if (kind == "help") "Help & Support" else "About Nonevid") },
    text = {
        Text(
            if (kind == "help") "Support is not connected to a server yet. This build is an early prototype."
            else "nonevid prototype 1.0. Sign-in, tokens, identity check and settings are stored only on this device and are not connected to any server."
        )
    },
)

@Composable
private fun ProfileStat(icon: @Composable () -> Unit, value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        icon()
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun MenuDivider() = HorizontalDivider(Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

@Composable
fun MenuRow(icon: ImageVector, title: String, sub: String? = null, badge: String? = null, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, Modifier.size(24.dp), tint = MaterialTheme.colorScheme.onBackground)
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, color = MaterialTheme.colorScheme.onBackground)
            if (sub != null) Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (badge != null) {
            Box(Modifier.size(22.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                Text(badge, fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(8.dp))
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
