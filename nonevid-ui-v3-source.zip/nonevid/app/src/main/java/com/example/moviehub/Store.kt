package com.example.moviehub

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.security.MessageDigest
import java.util.Locale
import kotlin.reflect.KProperty

// ===== Reward settings (for a quick test lower REWARD_SEC, e.g. 20) =====
const val REWARD_SEC = 900L      // every 15 minutes of watching
const val REWARD_TOKENS = 1000L
const val DAILY_BONUS = 500L
const val VIDEO_URL = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"

val accents = listOf(0xFF9B3DFF, 0xFF1E88E5, 0xFF43A047, 0xFFE91E63, 0xFFFB8C00, 0xFF00ACC1, 0xFF8E24AA, 0xFF6D4C41)

data class Movie(
    val id: Int, val title: String, val cat: String, val year: Int, val desc: String,
    val rating: Double, val views: String, val poster: Int,
)

// Ratings / view counts are demo values (same as the design mock-up).
val movies = listOf(
    Movie(1, "Inception", "Movies", 2010, "A thief who steals secrets from dreams takes on one last job.", 8.8, "12.5M", R.drawable.poster_inception),
    Movie(2, "Interstellar", "Movies", 2014, "Explorers cross a wormhole searching for a new home for humanity.", 8.6, "10.2M", R.drawable.poster_interstellar),
    Movie(3, "The Dark Knight", "Action", 2008, "A masked vigilante faces a chaos-loving criminal in Gotham.", 9.0, "14.8M", R.drawable.poster_dark_knight),
    Movie(4, "Avengers Endgame", "Action", 2019, "The surviving heroes assemble for one final stand.", 9.2, "16.7M", R.drawable.poster_avengers),
    Movie(5, "Fight Club", "Drama", 1999, "An office worker and a soap maker start an underground club.", 8.8, "13.2M", R.drawable.poster_fight_club),
    // Only five poster files exist, so the sixth card re-uses one (as requested).
    Movie(6, "The Matrix", "Action", 1999, "A hacker discovers the world around him is not what it seems.", 8.7, "11.9M", R.drawable.poster_alt_1),
)
val jokerMovie = Movie(0, "Joker", "Drama", 2019, "The world is a stage... and he's the chaos.", 8.4, "9.1M", R.drawable.poster_alt_5)
val allMovies = movies + jokerMovie

val notifTypes = listOf(
    "new" to "New movies", "episode" to "New episodes of saved series",
    "reward" to "Token rewards", "offer" to "Special offers", "security" to "Security alerts",
)

class Pref<T : Any>(private val sp: SharedPreferences, private val k: String, d: T) {
    @Suppress("UNCHECKED_CAST")
    private var st by mutableStateOf(when (d) {
        is Long -> sp.getLong(k, d); is Boolean -> sp.getBoolean(k, d)
        is Int -> sp.getInt(k, d); else -> sp.getString(k, d as String)
    } as T)
    operator fun getValue(r: Any?, p: KProperty<*>): T = st
    operator fun setValue(r: Any?, p: KProperty<*>, v: T) {
        st = v
        sp.edit().apply {
            when (v) {
                is Long -> putLong(k, v); is Boolean -> putBoolean(k, v)
                is Int -> putInt(k, v); else -> putString(k, v as String)
            }
        }.apply()
    }
}

data class Tx(val kind: String, val amount: Long, val time: Long)

class Store(c: Context) {
    private val sp = c.getSharedPreferences("app", 0)

    // Demo seed values match the design mock-up (balance 48,750 / 12.5h / 4 rewards).
    var tokens by Pref(sp, "tokens2", 48750L)
    var watchSec by Pref(sp, "watch2", 45000L)
    var rewards by Pref(sp, "rewards2", 4)
    var txLog by Pref(sp, "tx2", "")
    var lastBonusDay by Pref(sp, "bonusDay", 0L)
    var history by Pref(sp, "history", "")

    var loggedIn by Pref(sp, "in", false)
    var name by Pref(sp, "name", "")
    var phone by Pref(sp, "phone", "")
    var accounts by Pref(sp, "accounts", "")
    var verified by Pref(sp, "verified", false)
    var themeMode by Pref(sp, "theme2", 2)          // 0 auto, 1 light, 2 dark (design default)
    var accent by Pref(sp, "accent2", accents[0].toInt())
    var amoled by Pref(sp, "amoled", false)
    var notifs by Pref(sp, "notifs", "new,episode,reward,security")
    var savedIds by Pref(sp, "saved", "")
    var pinOn by Pref(sp, "pinOn", false)
    var pin by Pref(sp, "pin", "")
    var twoStep by Pref(sp, "twoStep", false)
    var secureScreen by Pref(sp, "secure", false)

    init {
        if (txLog.isEmpty()) {
            val now = System.currentTimeMillis()
            val h = 3_600_000L
            txLog = listOf(Tx("reward", 1000, now - 2 * h), Tx("bonus", 500, now - 24 * h), Tx("purchase", 5000, now - 48 * h))
                .joinToString(";") { "${it.kind}|${it.amount}|${it.time}" }
        }
    }

    fun txs(): List<Tx> = txLog.split(";").mapNotNull {
        val p = it.split("|")
        if (p.size == 3) Tx(p[0], p[1].toLongOrNull() ?: 0L, p[2].toLongOrNull() ?: 0L) else null
    }

    fun addTx(kind: String, amount: Long) {
        txLog = (listOf("$kind|$amount|${System.currentTimeMillis()}") + txLog.split(";").filter { it.isNotEmpty() })
            .take(50).joinToString(";")
    }

    /** Called once per second of real playback. Returns true when a reward was granted. */
    fun tick(): Boolean {
        watchSec += 1
        if (watchSec % REWARD_SEC == 0L) {
            tokens += REWARD_TOKENS; rewards += 1; addTx("reward", REWARD_TOKENS)
            return true
        }
        return false
    }

    /** Local-only daily bonus (once per calendar day on this device). */
    fun claimDaily(): Boolean {
        val day = System.currentTimeMillis() / 86_400_000L
        if (lastBonusDay == day) return false
        lastBonusDay = day; tokens += DAILY_BONUS; rewards += 1; addTx("bonus", DAILY_BONUS)
        return true
    }

    fun addHistory(id: Int) {
        history = (listOf(id.toString()) + history.split(",").filter { it.isNotEmpty() && it != id.toString() })
            .take(30).joinToString(",")
    }

    fun checkPin(input: String) = pin.isNotEmpty() && (pin == hashPin(input) || pin == input)
}

fun hashPin(p: String): String =
    MessageDigest.getInstance("SHA-256").digest("nonevid:$p".toByteArray()).joinToString("") { "%02x".format(it) }

fun has(s: String, k: String) = s.split(",").contains(k)
fun toggle(s: String, k: String) = s.split(",").filter { it.isNotEmpty() }.let { if (k in it) it - k else it + k }.joinToString(",")

fun validNationalCode(c: String): Boolean {
    if (!Regex("\\d{10}").matches(c) || c.all { it == c[0] }) return false
    val r = (0..8).sumOf { (c[it] - '0') * (10 - it) } % 11
    val k = c[9] - '0'
    return if (r < 2) k == r else k == 11 - r
}
fun validPhone(p: String) = Regex("^09\\d{9}$").matches(p)

fun fmt(n: Long): String = String.format(Locale.US, "%,d", n)
fun fmtK(n: Int): String = if (n >= 1000) String.format(Locale.US, "%.1fK", n / 1000.0) else n.toString()
fun timeAgo(t: Long): String {
    val m = (System.currentTimeMillis() - t) / 60_000L
    return when {
        m < 1 -> "Just now"
        m < 60 -> "${m}m ago"
        m < 1440 -> "${m / 60}h ago"
        else -> "${m / 1440}d ago"
    }
}
