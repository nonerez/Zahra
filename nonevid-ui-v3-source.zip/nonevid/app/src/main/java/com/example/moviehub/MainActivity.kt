package com.example.moviehub

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        val store = Store(this)
        setContent { App(store) }
    }
}

/** Screens that open on top of the four main tabs. */
sealed interface Ov {
    data class Play(val m: Movie) : Ov
    object Search : Ov
    object All : Ov
    object History : Ov
    object Transactions : Ov
    data class Page(val key: String) : Ov
}

class Nav(private val stack: SnapshotStateList<Ov>, private val setTab: (Int) -> Unit) {
    fun open(o: Ov) { stack.add(o) }
    fun back() { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }
    fun tab(i: Int) { stack.clear(); setTab(i) }
}

@Composable
fun App(st: Store) {
    val act = LocalContext.current as Activity
    LaunchedEffect(st.secureScreen) {
        if (st.secureScreen) act.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else act.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }
    NonevidTheme(st) {
        AppBackground {
            var unlocked by remember { mutableStateOf(!st.pinOn) }
            when {
                !unlocked -> PinScreen(st) { unlocked = true }
                !st.loggedIn -> LoginScreen(st)
                else -> MainScreen(st)
            }
        }
    }
}

@Composable
fun MainScreen(st: Store) {
    var tab by remember { mutableIntStateOf(0) }
    val stack = remember { mutableStateListOf<Ov>() }
    val nav = remember { Nav(stack) { tab = it } }
    BackHandler(stack.isNotEmpty()) { nav.back() }

    Box(Modifier.fillMaxSize()) {
        when (val top = stack.lastOrNull()) {
            null -> {
                when (tab) {
                    0 -> HomeScreen(st, nav)
                    1 -> ExploreScreen(st, nav)
                    2 -> WalletScreen(st, nav)
                    else -> ProfileScreen(st, nav)
                }
                BottomBar(tab, { nav.tab(it) }, Modifier.align(Alignment.BottomCenter))
            }
            is Ov.Play -> PlayerScreen(st, top.m) { nav.back() }
            is Ov.Search -> SearchScreen(nav)
            is Ov.All -> AllMoviesScreen(nav)
            is Ov.History -> HistoryScreen(st, nav)
            is Ov.Transactions -> TransactionsScreen(st, nav)
            is Ov.Page -> PageHost(st, nav, top.key)
        }
    }
}

@Composable
fun PinScreen(st: Store, onOk: () -> Unit) {
    var v by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Icon(Icons.Filled.Lock, null, Modifier.size(56.dp), tint = PurpleLight)
        Spacer(Modifier.height(16.dp))
        Text("Enter your PIN", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        OutlinedTextField(
            v, { val d = it.filter(Char::isDigit).take(4); v = d; if (d.length == 4 && st.checkPin(d)) onOk() },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            isError = v.length == 4 && !st.checkPin(v), singleLine = true, modifier = Modifier.padding(top = 16.dp),
        )
    }
}

@Composable
fun LoginScreen(st: Store) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    fun login(n: String, p: String) {
        st.name = n; st.phone = p; st.loggedIn = true
        if (!st.accounts.split(";").contains("$n|$p"))
            st.accounts = (st.accounts.split(";").filter { it.contains("|") } + "$n|$p").joinToString(";")
    }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Spacer(Modifier.height(24.dp))
        Image(painterResource(R.drawable.logo_nonevid), "nonevid", Modifier.width(180.dp).height(52.dp), contentScale = ContentScale.Fit, alignment = Alignment.CenterStart)
        Text("Welcome", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Text("Demo sign-in: accounts are stored only on this device.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        st.accounts.split(";").filter { it.contains("|") }.forEach { a ->
            val parts = a.split("|"); val n = parts[0]; val p = parts[1]
            Row(glass().fillMaxWidth().clickable { login(n, p) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.AccountCircle, null, Modifier.size(36.dp), tint = PurpleLight)
                Spacer(Modifier.width(12.dp))
                Column { Text(n, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground); Text(p, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }
        OutlinedTextField(name, { name = it }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            phone, { phone = it.take(11) }, label = { Text("Phone (09…)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth(),
        )
        GradientButton("Continue", Modifier.fillMaxWidth()) {
            val clean = name.replace(Regex("[;|]"), " ").trim()
            if (clean.isEmpty() || !validPhone(phone)) Toast.makeText(ctx, "Enter a username and a valid phone number", Toast.LENGTH_SHORT).show()
            else login(clean, phone)
        }
    }
}
