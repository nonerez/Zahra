package com.example.moviehub

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.RocketLaunch
import androidx.compose.material.icons.outlined.TheaterComedy
import androidx.compose.material.icons.outlined.Theaters
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val homeCats: List<Pair<String, ImageVector>> = listOf(
    "Movies" to Icons.Outlined.Theaters,
    "Series" to Icons.Outlined.VideoLibrary,
    "Animation" to Icons.Outlined.AutoAwesome,
    "Drama" to Icons.Outlined.TheaterComedy,
    "Action" to Icons.Outlined.RocketLaunch,
)

@Composable
fun HomeScreen(st: Store, nav: Nav) {
    var cat by remember { mutableStateOf<String?>(null) }
    val list = movies.filter { cat == null || it.cat == cat }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Hero(nav)
        SectionTitle("Categories", Modifier.padding(horizontal = 20.dp)) { nav.open(Ov.All) }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            homeCats.forEach { (name, icon) ->
                CatTile(name, icon, cat == name, Modifier.weight(1f)) { cat = if (cat == name) null else name }
            }
        }
        SectionTitle("Trending This Week", Modifier.padding(horizontal = 20.dp)) { nav.open(Ov.All) }
        if (list.isEmpty()) {
            Text("Nothing here yet.", Modifier.padding(horizontal = 20.dp, vertical = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(list) { m -> PosterCard(m, Modifier.width(112.dp)) { nav.open(Ov.Play(m)) } }
            }
        }
        Spacer(Modifier.height(16.dp))
        EarnBanner(Modifier.padding(horizontal = 16.dp)) { nav.tab(2) }
        Spacer(Modifier.height(120.dp))
    }
}

@Composable
private fun Hero(nav: Nav) {
    val bg = MaterialTheme.colorScheme.background
    Box(Modifier.fillMaxWidth().height(340.dp)) {
        // Wide banner, centre-cropped (never stretched) with the focus on the right so the face stays visible.
        Image(
            painterResource(R.drawable.joker_banner), "Joker", Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop, alignment = BiasAlignment(0.75f, 0f),
        )
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to Color(0x99000000), 0.3f to Color.Transparent, 0.65f to Color.Transparent, 1f to bg)))
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0f to Color(0xB307050D), 0.6f to Color.Transparent)))
        TopBar(nav, Modifier.align(Alignment.TopCenter), tint = Color.White)
        Column(Modifier.align(Alignment.BottomStart).padding(start = 24.dp, bottom = 36.dp)) {
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(Color(0x99000000))
                    .border(1.dp, Color(0x55FFFFFF), RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 4.dp),
            ) { Text("🔥 Hot & Popular", fontSize = 12.sp, color = Color.White) }
            Spacer(Modifier.height(10.dp))
            Text("Joker", fontSize = 54.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text("The world is a stage...\nand he's the chaos.", fontSize = 14.sp, color = Color(0xFFE6E0F2), lineHeight = 19.sp)
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier.clip(RoundedCornerShape(50))
                    .background(Brush.horizontalGradient(listOf(MaterialTheme.colorScheme.primary, PurpleLight)))
                    .clickable { nav.open(Ov.Play(jokerMovie)) }.padding(horizontal = 22.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.PlayArrow, null, tint = Color.White, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(8.dp))
                Text("Watch Now", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            }
        }
        // Decorative pager dots (a single banner for now).
        Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(5) { i ->
                Box(
                    Modifier.height(6.dp).width(if (i == 0) 18.dp else 6.dp).clip(CircleShape)
                        .background(if (i == 0) PurpleLight else Color(0x66FFFFFF)),
                )
            }
        }
    }
}

@Composable
private fun CatTile(name: String, icon: ImageVector, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier.height(84.dp).clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            .border(1.dp, if (selected) PurpleLight else MaterialTheme.colorScheme.outline.copy(alpha = 0.7f), shape)
            .clickable { onClick() },
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, name, Modifier.size(28.dp), tint = if (selected) PurpleLight else MaterialTheme.colorScheme.onBackground)
        Spacer(Modifier.height(6.dp))
        Text(name, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
fun PosterCard(m: Movie, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(modifier.clickable { onClick() }) {
        Box(Modifier.fillMaxWidth().aspectRatio(0.68f).clip(shape).border(1.dp, MaterialTheme.colorScheme.outline, shape)) {
            Image(painterResource(m.poster), m.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(
                Modifier.align(Alignment.TopEnd).padding(6.dp).size(22.dp).clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.PlayArrow, null, Modifier.size(14.dp), tint = Color.White) }
        }
        Spacer(Modifier.height(6.dp))
        Text(m.title, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, color = MaterialTheme.colorScheme.onBackground)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Star, null, Modifier.size(12.dp), tint = Gold)
            Text(" ${m.rating}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Filled.Visibility, null, Modifier.size(12.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(" ${m.views}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun EarnBanner(modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Row(
        modifier.fillMaxWidth().clip(shape)
            .background(Brush.horizontalGradient(listOf(Color(0xFF3B1480), Color(0xFF1E0B45))))
            .border(1.dp, Color(0x669B3DFF), shape).clickable { onClick() }.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(painterResource(R.drawable.coins), null, Modifier.size(78.dp), contentScale = ContentScale.Fit)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                "Watch & Earn", fontSize = 11.sp, color = Color.White,
                modifier = Modifier.clip(RoundedCornerShape(50)).background(Color(0xFF6A2CD8)).padding(horizontal = 10.dp, vertical = 3.dp),
            )
            Spacer(Modifier.height(4.dp))
            Row {
                Text("Earn ", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text(fmt(REWARD_TOKENS), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Gold)
                Text(" Tokens", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Text("for every ${REWARD_SEC / 60} minutes of watching!", fontSize = 11.sp, color = Color(0xFFCFC3E8))
        }
        Box(Modifier.size(36.dp).clip(CircleShape).background(Color(0xFF6A2CD8)), contentAlignment = Alignment.Center) {
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = Color.White)
        }
    }
}

@Composable
fun MovieGrid(list: List<Movie>, nav: Nav, modifier: Modifier = Modifier) {
    LazyVerticalGrid(
        GridCells.Fixed(3), modifier, contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 32.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(16.dp),
    ) { items(list) { m -> PosterCard(m) { nav.open(Ov.Play(m)) } } }
}

@Composable
fun AllMoviesScreen(nav: Nav) {
    Column(Modifier.fillMaxSize()) {
        SubHeader("All Movies") { nav.back() }
        MovieGrid(movies + jokerMovie, nav, Modifier.weight(1f))
    }
}

@Composable
fun SearchScreen(nav: Nav) {
    var q by remember { mutableStateOf("") }
    val res = (movies + jokerMovie).filter { q.isNotBlank() && it.title.contains(q.trim(), ignoreCase = true) }
    Column(Modifier.fillMaxSize().imePadding()) {
        SubHeader("Search") { nav.back() }
        OutlinedTextField(
            q, { q = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp), singleLine = true,
            placeholder = { Text("Search for movies, series...") },
            leadingIcon = { Icon(Icons.Filled.Search, null) }, shape = RoundedCornerShape(18.dp),
        )
        if (q.isNotBlank() && res.isEmpty()) Text("No results.", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        MovieGrid(res, nav, Modifier.weight(1f))
    }
}

@Composable
fun HistoryScreen(st: Store, nav: Nav) {
    val list = st.history.split(",").mapNotNull { id -> allMovies.firstOrNull { it.id.toString() == id } }
    Column(Modifier.fillMaxSize()) {
        SubHeader("Watch History") { nav.back() }
        if (list.isEmpty()) Text("Movies you open will show up here.", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list) { m ->
                Row(glass().fillMaxWidth().clickable { nav.open(Ov.Play(m)) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(m.poster), null, Modifier.size(width = 52.dp, height = 72.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(m.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                        Text("${m.cat} • ${m.year}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
