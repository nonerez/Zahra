package com.example.moviehub

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val PurpleLight = Color(0xFFB45CFF)
val Gold = Color(0xFFFFC21A)
val Green = Color(0xFF4ADE80)

@Composable
fun NonevidTheme(st: Store, content: @Composable () -> Unit) {
    val dark = when (st.themeMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val acc = Color(st.accent)
    val scheme = if (dark) {
        val bg = if (st.amoled) Color.Black else Color(0xFF07050D)
        darkColorScheme(
            primary = acc, onPrimary = Color.White, background = bg, onBackground = Color.White,
            surface = Color(0xFF120D1F), onSurface = Color(0xFFF2EEFA),
            surfaceVariant = Color(0xFF1B1530), onSurfaceVariant = Color(0xFFB9B2C9),
            primaryContainer = Color(0xFF2A1450), onPrimaryContainer = Color.White,
            outline = Color(0xFF3A2A5C),
        )
    } else {
        lightColorScheme(
            primary = acc, onPrimary = Color.White, background = Color(0xFFF6F2FF), onBackground = Color(0xFF14101F),
            surface = Color.White, onSurface = Color(0xFF14101F),
            surfaceVariant = Color(0xFFEDE6FA), onSurfaceVariant = Color(0xFF5E5575),
            primaryContainer = Color(0xFFE6D7FF), onPrimaryContainer = Color(0xFF14101F),
            outline = Color(0xFFCFC3E8),
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun AppBackground(content: @Composable BoxScope.() -> Unit) {
    val bg = MaterialTheme.colorScheme.background
    val top = if (bg == Color.Black) Color(0xFF12062A) else if (bg.red > 0.5f) Color(0xFFE9DDFF) else Color(0xFF1E0B3D)
    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(0f to top, 0.38f to bg, 1f to bg)),
        content = content,
    )
}

@Composable
fun glass(shape: Shape = RoundedCornerShape(20.dp)): Modifier = Modifier
    .clip(shape)
    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
    .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f)), shape)

@Composable
fun SectionTitle(title: String, modifier: Modifier = Modifier, onSeeAll: (() -> Unit)? = null) {
    Row(modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(4.dp).height(20.dp).clip(RoundedCornerShape(2.dp)).background(MaterialTheme.colorScheme.primary))
        Spacer(Modifier.width(8.dp))
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Spacer(Modifier.weight(1f))
        if (onSeeAll != null) Row(Modifier.clickable { onSeeAll() }, verticalAlignment = Alignment.CenterVertically) {
            Text("See All", fontSize = 13.sp, color = PurpleLight)
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, Modifier.size(18.dp), tint = PurpleLight)
        }
    }
}

/** Logo on the left, search + bell on the right. [tint] is white over images. */
@Composable
fun TopBar(nav: Nav, modifier: Modifier = Modifier, tint: Color = MaterialTheme.colorScheme.onBackground) {
    Row(
        modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            painterResource(R.drawable.logo_nonevid), "nonevid",
            Modifier.width(110.dp).height(32.dp), contentScale = ContentScale.Fit, alignment = Alignment.CenterStart,
        )
        Spacer(Modifier.weight(1f))
        IconButton({ nav.open(Ov.Search) }) { Icon(Icons.Filled.Search, "Search", tint = tint, modifier = Modifier.size(26.dp)) }
        // The purple dot is a demo indicator; the bell opens notification preferences.
        IconButton({ nav.open(Ov.Page("notifications")) }) {
            Box {
                Icon(Icons.Filled.Notifications, "Notifications", tint = tint, modifier = Modifier.size(26.dp))
                Box(Modifier.align(Alignment.TopEnd).size(9.dp).clip(CircleShape).background(PurpleLight))
            }
        }
    }
}

@Composable
fun BottomBar(tab: Int, onTab: (Int) -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)
    val items = listOf(
        Triple("Home", Icons.Filled.Home, Icons.Outlined.Home),
        Triple("Explore", Icons.Filled.Explore, Icons.Outlined.Explore),
        Triple("Wallet", Icons.Filled.AccountBalanceWallet, Icons.Outlined.AccountBalanceWallet),
        Triple("Profile", Icons.Filled.Person, Icons.Outlined.Person),
    )
    Row(
        modifier.fillMaxWidth().clip(shape)
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.94f))
            .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)), shape)
            .navigationBarsPadding().padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceAround,
    ) {
        items.forEachIndexed { i, (label, filled, outlined) ->
            val sel = tab == i
            val col = if (sel) PurpleLight else MaterialTheme.colorScheme.onSurfaceVariant
            Column(
                Modifier.weight(1f).clickable(remember { MutableInteractionSource() }, null) { onTab(i) },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    Modifier.width(56.dp).height(38.dp).clip(RoundedCornerShape(16.dp)).background(
                        if (sel) Brush.verticalGradient(listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.45f), MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)))
                        else Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent))
                    ),
                    contentAlignment = Alignment.Center,
                ) { Icon(if (sel) filled else outlined, label, tint = col, modifier = Modifier.size(26.dp)) }
                Text(label, fontSize = 11.sp, color = col)
            }
        }
    }
}

@Composable
fun SubHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = MaterialTheme.colorScheme.onBackground) }
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
    }
}

@Composable
fun GradientButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val p = MaterialTheme.colorScheme.primary
    Box(
        modifier.clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(p, PurpleLight)))
            .clickable { onClick() }.padding(horizontal = 24.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp) }
}
