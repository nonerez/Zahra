package com.example.moviehub

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.outlined.Bookmarks
import androidx.compose.material.icons.outlined.Devices
import androidx.compose.material.icons.outlined.Help
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Password
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PageHost(st: Store, nav: Nav, key: String) {
    var info by remember { mutableStateOf("") }
    val title = when (key) {
        "settings" -> "Settings"; "appearance" -> "Appearance"; "notifications" -> "Notifications"
        "security" -> "Security & Privacy"; "kyc" -> "Identity Verification"; "saved" -> "Saved Movies"
        else -> "Your Level"
    }
    Column(Modifier.fillMaxSize()) {
        SubHeader(title) { nav.back() }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            when (key) {
                "settings" -> Column(Modifier.padding(horizontal = 16.dp).then(glass()).fillMaxWidth()) {
                    MenuRow(Icons.Outlined.Palette, "Appearance", "Theme and app colours") { nav.open(Ov.Page("appearance")) }
                    MenuDivider()
                    MenuRow(Icons.Outlined.Notifications, "Notifications") { nav.open(Ov.Page("notifications")) }
                    MenuDivider()
                    MenuRow(Icons.Outlined.Lock, "Security & Privacy") { nav.open(Ov.Page("security")) }
                    MenuDivider()
                    MenuRow(Icons.Outlined.VerifiedUser, "Identity Verification", if (st.verified) "Demo check done" else "Not verified") { nav.open(Ov.Page("kyc")) }
                    MenuDivider()
                    MenuRow(Icons.Outlined.Bookmarks, "Saved Movies", "${st.savedIds.split(",").count { it.isNotEmpty() }} saved") { nav.open(Ov.Page("saved")) }
                    MenuDivider()
                    MenuRow(Icons.Outlined.PersonAdd, "Add Account") { st.loggedIn = false }
                    MenuDivider()
                    MenuRow(Icons.Outlined.Help, "Help & Support") { info = "help" }
                    MenuDivider()
                    MenuRow(Icons.Outlined.Info, "About Nonevid", "Prototype 1.0") { info = "about" }
                }
                "appearance" -> Appearance(st)
                "notifications" -> Notifications(st)
                "security" -> Security(st)
                "kyc" -> Kyc(st)
                "saved" -> Saved(st, nav)
                else -> Column(Modifier.padding(20.dp)) {
                    Text("Level progress is a demo value in this prototype.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
    if (info.isNotEmpty()) InfoDialog(info) { info = "" }
}

@Composable
fun SwitchRow(title: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), fontSize = 16.sp, color = MaterialTheme.colorScheme.onBackground)
        Switch(on, onChange)
    }
}

@Composable
fun Notifications(st: Store) {
    notifTypes.forEach { (k, t) -> SwitchRow(t, has(st.notifs, k)) { st.notifs = toggle(st.notifs, k) } }
    Text(
        "Demo: only your preference is saved; no real notifications are sent yet.",
        Modifier.padding(20.dp), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
fun Appearance(st: Store) {
    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Mode", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Auto", "Light", "Dark").forEachIndexed { i, t -> FilterChip(st.themeMode == i, { st.themeMode = i }, { Text(t) }) }
        }
        Text("Accent colour", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(accents) { c ->
                val col = Color(c)
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(col).clickable { st.accent = col.toArgb() },
                    contentAlignment = Alignment.Center,
                ) { if (st.accent == col.toArgb()) Icon(Icons.Filled.Check, null, tint = Color.White) }
            }
        }
        SwitchRow("Pure black background (AMOLED, dark mode)", st.amoled) { st.amoled = it }
    }
}

@Composable
fun Security(st: Store) {
    val ctx = LocalContext.current
    var dialog by remember { mutableStateOf(false) }
    var p by remember { mutableStateOf("") }
    SwitchRow("App lock (4-digit PIN)", st.pinOn) { if (it) { p = ""; dialog = true } else { st.pinOn = false; st.pin = "" } }
    if (st.pinOn) MenuRow(Icons.Outlined.Password, "Change PIN") { p = ""; dialog = true }
    SwitchRow("Two-step verification (demo, not enforced)", st.twoStep) { st.twoStep = it }
    SwitchRow("Block screenshots & screen recording", st.secureScreen) { st.secureScreen = it }
    MenuRow(Icons.Outlined.Devices, "Sign out of other devices") {
        Toast.makeText(ctx, "Demo: all data exists only on this device", Toast.LENGTH_SHORT).show()
    }
    if (dialog) AlertDialog(
        onDismissRequest = { dialog = false }, title = { Text("New 4-digit PIN") },
        text = {
            OutlinedTextField(
                p, { p = it.filter(Char::isDigit).take(4) }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            )
        },
        confirmButton = { TextButton({ if (p.length == 4) { st.pin = hashPin(p); st.pinOn = true; dialog = false } }) { Text("Save") } },
        dismissButton = { TextButton({ dialog = false }) { Text("Cancel") } },
    )
}

@Composable
fun Kyc(st: Store) {
    val ctx = LocalContext.current
    var nc by remember { mutableStateOf("") }
    var ph by remember { mutableStateOf(st.phone) }
    var sent by remember { mutableStateOf(false) }
    var otp by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (st.verified) {
            Text("Demo verification done ✅ (no real identity lookup was performed)", color = MaterialTheme.colorScheme.onBackground)
            return@Column
        }
        Text(
            "Demo: only the format of the national ID and phone number is checked. No official lookup is made.",
            color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp,
        )
        OutlinedTextField(
            nc, { nc = it.filter(Char::isDigit).take(10) }, label = { Text("National ID") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            ph, { ph = it.take(11) }, label = { Text("Phone number") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth(),
        )
        err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (!sent) {
            GradientButton("Send code", Modifier.fillMaxWidth()) {
                err = when {
                    !validNationalCode(nc) -> "Invalid National ID"
                    !validPhone(ph) -> "Invalid phone number"
                    else -> null
                }
                // TODO: call a licensed national-ID/phone matching service here (e.g. via an approved provider).
                if (err == null) { sent = true; Toast.makeText(ctx, "Demo code: 12345", Toast.LENGTH_LONG).show() }
            }
        } else {
            OutlinedTextField(
                otp, { otp = it.filter(Char::isDigit).take(5) }, label = { Text("SMS code") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(),
            )
            GradientButton("Verify", Modifier.fillMaxWidth()) { if (otp == "12345") st.verified = true else err = "Wrong code" }
        }
    }
}

@Composable
fun Saved(st: Store, nav: Nav) {
    val list = allMovies.filter { has(st.savedIds, it.id.toString()) }
    if (list.isEmpty()) Text("Nothing saved yet. Open a movie and tap the bookmark.", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        list.forEach { m ->
            Row(glass().fillMaxWidth().clickable { nav.open(Ov.Play(m)) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(m.poster), null, Modifier.size(width = 52.dp, height = 72.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(m.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    Text("${m.cat} • ${m.year}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton({ st.savedIds = toggle(st.savedIds, m.id.toString()) }) { Icon(Icons.Filled.Delete, "Remove", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }
    }
}
