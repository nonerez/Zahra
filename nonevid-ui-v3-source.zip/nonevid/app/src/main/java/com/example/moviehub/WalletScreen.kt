package com.example.moviehub

import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

@Composable
fun WalletScreen(st: Store, nav: Nav) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar(nav)
        TokenCard(st, Modifier.padding(horizontal = 16.dp)) {
            if (st.claimDaily()) Toast.makeText(ctx, "+${fmt(DAILY_BONUS)} tokens added", Toast.LENGTH_SHORT).show()
            else Toast.makeText(ctx, "Daily bonus already claimed today", Toast.LENGTH_SHORT).show()
        }
        SectionTitle("Wallet Stats", Modifier.padding(start = 20.dp, end = 20.dp, top = 12.dp)) { nav.open(Ov.Transactions) }
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(R.drawable.play_circle, String.format(Locale.US, "%.1fh", st.watchSec / 3600.0), "Watching", Modifier.weight(1f))
            StatTile(R.drawable.gift_orange, st.rewards.toString(), "Rewards", Modifier.weight(1f))
            StatTile(R.drawable.trophy, "#245", "Rank", Modifier.weight(1f)) // rank is a demo value
        }
        SectionTitle("Recent Transactions", Modifier.padding(start = 20.dp, end = 20.dp, top = 12.dp)) { nav.open(Ov.Transactions) }
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            st.txs().take(3).forEach { TxRow(it) }
        }
        Text(
            "Demo data: starting balance, rank and sample transactions are placeholders stored only on this device.",
            Modifier.padding(20.dp), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(110.dp))
    }
}

@Composable
private fun TokenCard(st: Store, modifier: Modifier, onClaim: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Box(
        modifier.fillMaxWidth().clip(shape)
            .background(Brush.linearGradient(listOf(Color(0xFF6A2CD8), Color(0xFF2E1068), Color(0xFF45179A))))
            .border(1.dp, Color(0x669B3DFF), shape).padding(18.dp),
    ) {
        Sparkline(Modifier.align(Alignment.CenterEnd).padding(top = 20.dp).size(width = 190.dp, height = 70.dp))
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.AccountBalanceWallet, null, Modifier.size(64.dp), tint = Color(0xFFD2B3FF))
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text("Your Tokens", color = Color(0xFFE6DAFF), fontSize = 15.sp)
                    Text(fmt(st.tokens), color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold)
                }
                // +12.5% is a demo figure
                Text("↑ +12.5%", color = Green, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.Top))
            }
            Spacer(Modifier.height(26.dp))
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(Color(0x66210B4A))
                    .border(1.dp, Color(0x559B3DFF), RoundedCornerShape(50)).clickable { onClaim() }.padding(horizontal = 18.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Spacer(Modifier.weight(1f))
                Image(painterResource(R.drawable.gift_orange), null, Modifier.size(34.dp), contentScale = ContentScale.Fit)
                Spacer(Modifier.width(10.dp))
                Text("Claim Daily Bonus", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Spacer(Modifier.weight(1f))
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = Color.White)
            }
        }
    }
}

@Composable
private fun Sparkline(modifier: Modifier) {
    val pts = listOf(0.15f, 0.30f, 0.20f, 0.40f, 0.35f, 0.55f, 0.50f, 0.70f, 0.62f, 0.90f)
    Canvas(modifier) {
        val w = size.width; val h = size.height
        val line = Path(); val area = Path()
        pts.forEachIndexed { i, v ->
            val x = w * i / (pts.size - 1); val y = h * (1f - v)
            if (i == 0) { line.moveTo(x, y); area.moveTo(x, h); area.lineTo(x, y) } else { line.lineTo(x, y); area.lineTo(x, y) }
        }
        area.lineTo(w, h); area.close()
        drawPath(area, Brush.verticalGradient(listOf(Color(0x66B45CFF), Color.Transparent)))
        drawPath(line, Color(0xFFC08BFF), style = Stroke(width = 5f, cap = StrokeCap.Round))
    }
}

@Composable
private fun StatTile(img: Int, value: String, label: String, modifier: Modifier) {
    Column(glass(RoundedCornerShape(18.dp)).then(modifier).padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Image(painterResource(img), null, Modifier.size(40.dp), contentScale = ContentScale.Fit)
        Spacer(Modifier.height(6.dp))
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun TxRow(t: Tx) {
    val title = when (t.kind) { "reward" -> "Watch Reward"; "bonus" -> "Daily Bonus"; else -> "Token Purchase" }
    Row(glass(RoundedCornerShape(18.dp)).fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        when (t.kind) {
            "reward" -> Image(painterResource(R.drawable.play_circle), null, Modifier.size(44.dp))
            "bonus" -> Image(painterResource(R.drawable.gift_orange), null, Modifier.size(44.dp))
            else -> Box(
                Modifier.size(44.dp).clip(CircleShape).background(Brush.verticalGradient(listOf(Color(0xFF8A3DFF), Color(0xFF4A18B0)))),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.ShoppingCart, null, tint = Color.White, modifier = Modifier.size(24.dp)) }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
            Text("+${fmt(t.amount)} Tokens", fontSize = 12.sp, color = Green)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("+${fmt(t.amount)}", color = Green, fontWeight = FontWeight.Bold)
            Text(timeAgo(t.time), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun TransactionsScreen(st: Store, nav: Nav) {
    Column(Modifier.fillMaxSize()) {
        SubHeader("Transactions") { nav.back() }
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(st.txs()) { TxRow(it) }
        }
    }
}
