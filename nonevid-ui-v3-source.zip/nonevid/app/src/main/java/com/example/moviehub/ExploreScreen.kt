package com.example.moviehub

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

// Demo feed: usernames, captions and counters are placeholders (no server behind them).
private data class Feed(val user: String, val caption: String, val likes: Int, val comments: Int, val shares: Int, val url: String)

private const val SAMPLE = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/"

private val feed = listOf(
    Feed("nonevid", "Just another night in Gotham... 💜\n#joker #movie #nonevid", 231_200, 4_892, 23_700, SAMPLE + "ForBiggerBlazes.mp4"),
    Feed("cinema_fan", "Neon rain and a long coat. 🎬\n#cinema #noir #nonevid", 98_400, 1_204, 8_800, SAMPLE + "ForBiggerEscapes.mp4"),
    Feed("movie_daily", "One more scene before sleep 🍿\n#movies #nonevid", 45_300, 732, 4_100, SAMPLE + "ForBiggerFun.mp4"),
    Feed("film_zone", "Quiet streets, loud thoughts ✨\n#film #nonevid", 67_800, 915, 6_200, SAMPLE + "ForBiggerJoyrides.mp4"),
    Feed("arman_edit", "Edit of the night 🎞️\n#edit #nonevid", 31_500, 408, 2_500, SAMPLE + "ForBiggerMeltdowns.mp4"),
)

@Composable
fun ExploreScreen(st: Store, nav: Nav) {
    val ctx = LocalContext.current
    var forYou by remember { mutableStateOf(true) }
    var liked by remember { mutableStateOf(setOf<Int>()) }
    var followed by remember { mutableStateOf(setOf<String>()) }
    var commentsOpen by remember { mutableStateOf(false) }
    val items = feed.withIndex().filter { forYou || it.value.user in followed }
    val exo = remember { ExoPlayer.Builder(ctx).build().apply { repeatMode = Player.REPEAT_MODE_ONE; playWhenReady = true } }
    DisposableEffect(Unit) { onDispose { exo.release() } }
    PauseOnBackground(exo)
    val failed = rememberPlayerFailed(exo)

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (items.isEmpty()) {
            LaunchedEffect(Unit) { exo.pause() }
            Image(painterResource(R.drawable.explore_bg), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Color(0xCC07050D)))
            Text(
                "Follow creators on the For You tab to see their videos here.",
                Modifier.align(Alignment.Center).padding(40.dp), color = Color.White, fontSize = 15.sp,
            )
        } else {
            val pager = rememberPagerState(pageCount = { items.size })
            val currentUrl = items.getOrNull(pager.currentPage)?.value?.url
            LaunchedEffect(currentUrl) {
                if (currentUrl != null) {
                    exo.setMediaItem(MediaItem.fromUri(currentUrl)); exo.prepare(); exo.playWhenReady = true
                }
            }
            VerticalPager(pager, Modifier.fillMaxSize()) { page ->
                val (index, f) = items[page]
                FeedPage(
                    f, index in liked, f.user in followed,
                    exo = if (page == pager.currentPage) exo else null, failed = failed.value,
                    onLike = { liked = if (index in liked) liked - index else liked + index },
                    onFollow = { followed = if (f.user in followed) followed - f.user else followed + f.user },
                    onComment = { commentsOpen = true },
                    onShare = {
                        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "Check out nonevid (demo)") }
                        ctx.startActivity(Intent.createChooser(send, "Share"))
                    },
                )
            }
        }

        Column(Modifier.align(Alignment.TopCenter)) {
            TopBar(nav, tint = Color.White)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                FeedTab("Following", !forYou) { forYou = false }
                Spacer(Modifier.width(28.dp))
                FeedTab("For You", forYou) { forYou = true }
            }
        }
    }

    if (commentsOpen) AlertDialog(
        onDismissRequest = { commentsOpen = false },
        confirmButton = { TextButton({ commentsOpen = false }) { Text("Close") } },
        title = { Text("Comments") },
        text = { Text("Demo only: comments are not connected to a server yet.") },
    )
}

@Composable
private fun FeedTab(text: String, selected: Boolean, onClick: () -> Unit) {
    Column(Modifier.clickable { onClick() }, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text, fontSize = 17.sp, color = if (selected) Color.White else Color(0xB3FFFFFF),
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        )
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier.width(44.dp).height(3.dp).clip(RoundedCornerShape(2.dp))
                .background(if (selected) PurpleLight else Color.Transparent),
        )
    }
}

@Composable
private fun FeedPage(
    f: Feed, liked: Boolean, following: Boolean, exo: ExoPlayer?, failed: Boolean,
    onLike: () -> Unit, onFollow: () -> Unit, onComment: () -> Unit, onShare: () -> Unit,
) {
    Box(Modifier.fillMaxSize()) {
        Image(painterResource(R.drawable.explore_bg), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        if (exo != null && !failed) {
            AndroidView(
                factory = { c ->
                    PlayerView(c).also {
                        it.useController = false
                        it.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        it.setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                        it.player = exo
                    }
                },
                modifier = Modifier.fillMaxSize().clickable { exo.playWhenReady = !exo.playWhenReady },
            )
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to Color(0x80000000), 0.25f to Color.Transparent, 0.6f to Color.Transparent, 1f to Color(0xE607050D))))

        // Right action column
        Column(
            Modifier.align(Alignment.BottomEnd).padding(end = 14.dp, bottom = 190.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(Modifier.size(58.dp)) {
                Image(painterResource(R.drawable.play_circle), null, Modifier.size(52.dp).align(Alignment.TopCenter), contentScale = ContentScale.Fit)
                Box(Modifier.align(Alignment.BottomCenter).size(20.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Add, null, Modifier.size(14.dp), tint = Color.White)
                }
            }
            Action(Icons.Filled.Favorite, fmtK(f.likes + if (liked) 1 else 0), if (liked) Color(0xFFFF3D7F) else Color.White, onLike)
            Action(Icons.Filled.ChatBubble, fmt(f.comments.toLong()), Color.White, onComment)
            Action(Icons.Filled.Share, fmtK(f.shares), Color.White, onShare)
            Box(
                Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(Color(0x66FFFFFF)).border(1.dp, Color(0x55FFFFFF), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.MusicNote, null, tint = Color.White, modifier = Modifier.size(28.dp)) }
        }

        // Bottom info
        Column(Modifier.align(Alignment.BottomStart).padding(start = 20.dp, end = 90.dp, bottom = 110.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).clip(CircleShape).border(2.dp, PurpleLight, CircleShape).background(Color(0xFF1B1530)), contentAlignment = Alignment.Center) {
                    Image(painterResource(R.drawable.play_circle), null, Modifier.size(30.dp))
                }
                Spacer(Modifier.width(10.dp))
                Text(f.user, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.width(12.dp))
                Text(
                    if (following) "Following" else "Follow", color = Color.White, fontSize = 13.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50)).border(1.dp, Color(0xAAFFFFFF), RoundedCornerShape(50))
                        .clickable { onFollow() }.padding(horizontal = 16.dp, vertical = 6.dp),
                )
            }
            Spacer(Modifier.height(10.dp))
            Text(f.caption, color = Color.White, fontSize = 15.sp, lineHeight = 21.sp)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.MusicNote, null, Modifier.size(18.dp), tint = Color.White)
                Spacer(Modifier.width(6.dp))
                Text("Original Sound - ${f.user}", color = Color.White, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun Action(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, tint: Color, onClick: () -> Unit) {
    Column(Modifier.clickable { onClick() }, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, Modifier.size(38.dp), tint = tint)
        Text(label, color = Color.White, fontSize = 13.sp)
    }
}
