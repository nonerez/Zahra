package com.example.moviehub

import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

@Composable
fun PlayerScreen(st: Store, m: Movie, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val exo = remember { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(VIDEO_URL)); prepare(); playWhenReady = true } }
    DisposableEffect(Unit) { onDispose { exo.release() } }
    PauseOnBackground(exo)
    val failed = rememberPlayerFailed(exo)
    LaunchedEffect(m.id) { st.addHistory(m.id) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            // Only real playback counts towards the reward (paused/buffering/background does not).
            if (exo.isPlaying && st.tick()) Toast.makeText(ctx, "🎉 +${fmt(REWARD_TOKENS)} tokens", Toast.LENGTH_LONG).show()
        }
    }
    val saved = has(st.savedIds, m.id.toString())
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = MaterialTheme.colorScheme.onBackground) }
            Text(m.title, Modifier.weight(1f), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            IconButton({ st.savedIds = toggle(st.savedIds, m.id.toString()) }) {
                Icon(if (saved) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder, "Save", tint = PurpleLight)
            }
        }
        AndroidView({ c -> PlayerView(c).also { it.player = exo } }, Modifier.fillMaxWidth().aspectRatio(16 / 9f))
        if (failed.value) PlayerError(Modifier.fillMaxWidth()) { exo.prepare(); exo.play() }
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${m.cat} • ${m.year} • ★ ${m.rating}", color = PurpleLight, fontWeight = FontWeight.SemiBold)
            Text(m.desc, color = MaterialTheme.colorScheme.onBackground)
            Text("Demo video: every title plays the same public sample clip.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            Text("Next reward (+${fmt(REWARD_TOKENS)} tokens)", fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground)
            LinearProgressIndicator(
                progress = { (st.watchSec % REWARD_SEC) / REWARD_SEC.toFloat() },
                Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                color = MaterialTheme.colorScheme.primary, trackColor = MaterialTheme.colorScheme.outline,
            )
        }
    }
}

/** Pauses playback when the app goes to the background and resumes it on return (reward counting stops too). */
@Composable
fun PauseOnBackground(exo: ExoPlayer) {
    val owner = LocalContext.current as ComponentActivity
    DisposableEffect(exo, owner) {
        var wasPlaying = false
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_PAUSE) { wasPlaying = exo.playWhenReady; exo.pause() }
            else if (e == Lifecycle.Event.ON_RESUME) { if (wasPlaying) exo.play() }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
}

@Composable
fun rememberPlayerFailed(exo: ExoPlayer): State<Boolean> {
    val failed = remember(exo) { mutableStateOf(false) }
    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) { failed.value = true }
            override fun onPlaybackStateChanged(playbackState: Int) { if (playbackState == Player.STATE_READY) failed.value = false }
        }
        exo.addListener(l)
        onDispose { exo.removeListener(l) }
    }
    return failed
}

@Composable
fun PlayerError(modifier: Modifier = Modifier, color: Color = Color.Unspecified, onRetry: () -> Unit) {
    Column(modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Playback failed. Check your internet connection.", color = color)
        Button(onRetry) { Text("Try again") }
    }
}
